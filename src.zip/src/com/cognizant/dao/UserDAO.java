package com.cognizant.dao;

import java.util.List;

import com.cognizant.vo.UserVO;

public interface UserDAO {

	Long addUserDetails(UserVO user);

	List<UserVO> getUsersDetails();

	UserVO getUserDetails(Long accountNo);
}