package com.cognizant.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cognizant.entity.User;
import com.cognizant.vo.UserVO;

@Repository("userDao")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public Long addUserDetails(UserVO userVO) {
		User user = prepareUser(userVO);
		Long accountNumber = (Long) sessionFactory.getCurrentSession().save(user);
		return accountNumber;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserVO> getUsersDetails() {
		List<User> users = sessionFactory.getCurrentSession().createCriteria(User.class).list();
		List<UserVO> usersVO = new ArrayList<UserVO>(users.size());
		for (User user : users) {
			usersVO.add(prepareUserVO(user));
		}
		return usersVO;
	}

	@Override
	public UserVO getUserDetails(Long accountNo) {
		return prepareUserVO((User) sessionFactory.getCurrentSession().get(User.class, accountNo));
	}

	private User prepareUser(UserVO userVO) {
		return new User(userVO.getAccountNumber(), userVO.getAccountType(), userVO.getAccountHolderName(),
				userVO.getAccountBalance());
	}

	private UserVO prepareUserVO(User user) {
		return new UserVO(user.getAccountNumber(), user.getAccountType(), user.getAccountHolderName(),
				user.getAccountBalance());
	}

}