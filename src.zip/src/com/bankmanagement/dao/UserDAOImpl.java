package com.bankmanagement.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.bankmanagement.entity.User;
import com.bankmanagement.vo.UserVO;

@Repository("userDao")
public class UserDAOImpl implements UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public void updateUserDetails(UserVO userVO) {
		sessionFactory.getCurrentSession()
				.createQuery("update User set accountBalance = :balance where accountNumber = :accountNumber")
				.setParameter("balance", userVO.getAccountBalance())
				.setParameter("accountNumber", userVO.getAccountNumber()).executeUpdate();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<UserVO> getUsersDetails() {
		List<User> users = sessionFactory.getCurrentSession().createCriteria(User.class).list();
		return getUsersVO(users);
	}

	@Override
	public UserVO getUserDetails(Long accountNo) {
		return getUserVO((User) sessionFactory.getCurrentSession().get(User.class, accountNo));
	}

	private UserVO getUserVO(User user) {
		if (user != null) {
			return new UserVO(user.getAccountNumber(), user.getAccountType(), user.getAccountHolderName(),
					user.getAccountBalance());
		}
		return null;
	}

	private List<UserVO> getUsersVO(List<User> users) {
		if (CollectionUtils.isEmpty(users)) {
			return Collections.emptyList();
		}

		List<UserVO> usersVO = new ArrayList<UserVO>(users.size());
		for (User user : users) {
			usersVO.add(getUserVO(user));
		}
		return usersVO;
	}
}