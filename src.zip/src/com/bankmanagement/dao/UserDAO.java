package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.vo.UserVO;

public interface UserDAO {

	void updateUserDetails(UserVO userVO);

	List<UserVO> getUsersDetails();

	UserVO getUserDetails(Long accountNo);
}