package com.bankmanagement.dao;

import java.util.List;
import java.util.ArrayList;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.util.CollectionUtils;

import com.bankmanagement.entity.UserDetails;
import com.bankmanagement.vo.TransactionDetailsVO;

@Repository("vdao")
public class ViewTransactionDaoImpl implements ViewTransactionDao {

	@Autowired
	SessionFactory sessionFactory;

	/*
	 * @SuppressWarnings("unchecked")
	 * 
	 * @Override public List<TransactionDetailsVO>
	 * retrieveTransactionDetails(Long accountNumber, Long transactionId) {
	 * 
	 * List<UserDetails> usersdetails =
	 * sessionFactory.getCurrentSession().createCriteria(UserDetails.class).list
	 * (); List<TransactionDetailsVO> tdvo = new
	 * ArrayList<TransactionDetailsVO>(usersdetails.size()); for (UserDetails
	 * user : usersdetails) { tdvo.add(prepareUserVO(user)); } return tdvo; }
	 */
	@SuppressWarnings("unchecked")
	@Override
	public TransactionDetailsVO retrieveTransactionDetails(Long accountNumber, Long transactionId) {

		Query query = sessionFactory.getCurrentSession()
				.createQuery("from UserDetails where accountNumber = :acNo and transactionId = :tid");
		query.setParameter("acNo", accountNumber);
		query.setParameter("tid", transactionId);

		List<UserDetails> users = query.list();
		if (!CollectionUtils.isEmpty(users)) {
			return getTransactionDetailsVO(users.get(0));
		}
		return null;

	}

	private TransactionDetailsVO getTransactionDetailsVO(UserDetails userDetails) {
		if (userDetails != null) {
			return new TransactionDetailsVO(userDetails.getAccountNumber(), userDetails.getCustomerName(),
					userDetails.getTransactionType(), userDetails.getTransactionAmount(), userDetails.getDescription());
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<TransactionDetailsVO> retrieveTransactionDetails(Long accountNumber) {
		Query query = sessionFactory.getCurrentSession().createQuery("from UserDetails where accountNumber = :acNo");
		query.setParameter("acNo", accountNumber);

		return query.list();

	}

	private TransactionDetailsVO prepareUserVO(UserDetails user) {
		return new TransactionDetailsVO(user.getAccountNumber(), user.getCustomerName(), user.getTransactionType(),
				user.getTransactionAmount(), user.getDescription());
	}

	@SuppressWarnings("unchecked")
	@Override
	public TransactionDetailsVO retrieveTransactionDetailsFromTransactionId(Long transactionId) {
		Query query = sessionFactory.getCurrentSession().createQuery("from UserDetails where transactionId = :tid");
		query.setParameter("tid", transactionId);

		List<UserDetails> users = query.list();
		if (!CollectionUtils.isEmpty(users)) {
			return getTransactionDetailsVO(users.get(0));
		}
		return null;

	}

}
