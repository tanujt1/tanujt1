package com.bankmanagement.dao;

import java.util.List;

import com.bankmanagement.vo.TransactionDetailsVO;

public interface ViewTransactionDao {

	TransactionDetailsVO retrieveTransactionDetails(Long accountNumber, Long transactionId);

	List<TransactionDetailsVO> retrieveTransactionDetails(Long accountNumber);

	TransactionDetailsVO retrieveTransactionDetailsFromTransactionId(Long transactionId);

}
