package com.bankmanagement.dao;

import com.bankmanagement.vo.TransactionDetailsVO;

public interface PerformTransactionDAO {

	Double updateTransactionDetails(TransactionDetailsVO tvo);

}
