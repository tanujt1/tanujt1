package com.bankmanagement.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankmanagement.entity.UserDetails;
import com.bankmanagement.vo.TransactionDetailsVO;

@Repository("dao")
public class PerformTransactionDAOImpl implements PerformTransactionDAO {

	@Autowired
	SessionFactory sessionfactory;

	@Override
	public Double updateTransactionDetails(TransactionDetailsVO tvo) {
		UserDetails ud = prepareUser(tvo);
		Long transaction_Id = (Long) sessionfactory.getCurrentSession().save(ud);
		Double d = transaction_Id.doubleValue();
		return d;
	}

	private UserDetails prepareUser(TransactionDetailsVO tvo) {
		return new UserDetails(tvo.getAccountNumber(), tvo.getCustomerName(), tvo.getTransactionType(),
				tvo.getTransactionAmount(), tvo.getDescription());
	}

	private TransactionDetailsVO prepareUserVO(UserDetails user) {
		return new TransactionDetailsVO(user.getAccountNumber(), user.getCustomerName(), user.getTransactionType(),
				user.getTransactionAmount(), user.getDescription());
	}

}
