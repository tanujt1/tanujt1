package com.bankmanagement.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.service.PerformTransactionService;
import com.bankmanagement.vo.TransactionDetailsVO;

@Controller
public class PerformTransactionController {

	@Autowired
	private PerformTransactionService service;

	@Autowired
	private Validator validator;

	@ResponseBody
	@RequestMapping(value = "static/html/save", method = RequestMethod.POST)
	ModelAndView initiateTransaction(@RequestParam(value = "customerName") String customerName,
			@RequestParam(value = "accountNumber") Long accountNumber,

			@RequestParam(value = "transactionType") String transactionType,
			@RequestParam(value = "transactionAmount") Double transactionAmount,
			@RequestParam(value = "description") String description)

	{

		TransactionDetailsVO tdvo = new TransactionDetailsVO(accountNumber, customerName, transactionType,
				transactionAmount, description);

		Set<ConstraintViolation<TransactionDetailsVO>> validationErrors = validator.validate(tdvo);
		if (!validationErrors.isEmpty()) {
			Map<String, String> errors = getVallidationErrors(validationErrors);
			return new ModelAndView("Performtransaction", "errors", errors);

		}

		try {
			Double tid = service.updateTransactionDetails(tdvo);
			tdvo.setTransactionAmount(tid);
			return new ModelAndView("transactionDetails", "user", tid);
		} catch (BankManagementException ex) {
			return new ModelAndView("Performtransaction", ex.getErrorKey(), ex.getMessage());
		}

	}

	@RequestMapping(value = "static/html/performTransactionForm", method = RequestMethod.GET)
	public String initiateTransactionForm() {
		return "Performtransaction";
	}

	private Map<String, String> getVallidationErrors(Set<ConstraintViolation<TransactionDetailsVO>> validationErrors) {
		Map<String, String> errors = new HashMap<String, String>(validationErrors.size());
		for (ConstraintViolation<TransactionDetailsVO> constraintViolation : validationErrors) {
			errors.put(constraintViolation.getPropertyPath().toString(), constraintViolation.getMessage());
		}
		return errors;
	}

}
