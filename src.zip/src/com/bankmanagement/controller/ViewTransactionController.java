package com.bankmanagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import com.bankmanagement.service.ViewTransactionService;
import com.bankmanagement.vo.TransactionDetailsVO;

@Controller
public class ViewTransactionController {

	@Autowired
	ViewTransactionService viewService;

	@ResponseBody
	@RequestMapping(value = "/static/html/viewUserDetailsRest", method = RequestMethod.POST)
	List<TransactionDetailsVO> searchUserTransactionRest(Long accountNumber, Long transactionId) {
		return viewService.retrieveTransactionDetails(accountNumber, transactionId);
	}

	@RequestMapping(value = "/static/html/viewDetails", method = RequestMethod.GET)
	ModelAndView searchUserTransaction(@RequestParam(value = "accountNumber") Long accountNumber,
			@RequestParam(value = "transactionId") Long transactionId) {
		List<TransactionDetailsVO> list = viewService.retrieveTransactionDetails(accountNumber, transactionId);
		System.out.println(accountNumber + "" + transactionId);
		return new ModelAndView("showUserDetails", "list", list);
	}
}
