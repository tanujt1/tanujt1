package com.bankmanagement.service;

import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.TransactionDetailsVO;

public interface PerformTransactionService {

	Double updateTransactionDetails(TransactionDetailsVO tdvo) throws BankManagementException;

}
