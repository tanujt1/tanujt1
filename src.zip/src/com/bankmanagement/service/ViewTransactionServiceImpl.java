package com.bankmanagement.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankmanagement.dao.ViewTransactionDao;
import com.bankmanagement.vo.TransactionDetailsVO;

@Service("viewService")
public class ViewTransactionServiceImpl implements ViewTransactionService {

	@Autowired
	ViewTransactionDao vdao;

	@Transactional
	@Override
	public List<TransactionDetailsVO> retrieveTransactionDetails(Long accountNumber, Long transactionId) {
		if (accountNumber != null && transactionId != null) {
			TransactionDetailsVO transactionsVO = vdao.retrieveTransactionDetails(accountNumber, transactionId);
			if (transactionsVO != null) {
				return Arrays.asList(transactionsVO);
			}
		}

		else if (accountNumber != null && transactionId == null) {
			List<TransactionDetailsVO> transactionsVO = vdao.retrieveTransactionDetails(accountNumber);
			if (transactionsVO != null) {
				return transactionsVO;
			}
		}

		else if (accountNumber == null && transactionId != null) {
			TransactionDetailsVO transactionsVO = vdao.retrieveTransactionDetailsFromTransactionId(transactionId);
			if (transactionsVO != null) {
				return Arrays.asList(transactionsVO);
			}
		} else {
			return null;
		}

		return null;

		// return Arrays.asList(vdao.retrieveTransactionDetails(accountNumber,
		// transactionId));
	}

}
/*
 * @Transactional
 * 
 * @Override public List<TransactionDetailsVO> retrieveTransactionDetails(Long
 * accountNumber, Long transactionId) { if(accountNumber!=null &&
 * transactionId!=null) { return vdao.retrieveTransactionDetails(accountNumber,
 * transactionId); }
 * 
 * 
 * 
 * return vdao.retrieveTransactionDetails(accountNumber, transactionId); }
 */
