package com.bankmanagement.service;

import java.util.List;

import com.bankmanagement.vo.TransactionDetailsVO;

public interface ViewTransactionService {

	List<TransactionDetailsVO> retrieveTransactionDetails(Long accountNumber, Long transactionId);

}
