package com.bankmanagement.service;

import java.text.MessageFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankmanagement.dao.PerformTransactionDAO;
import com.bankmanagement.dao.UserDAO;
import com.bankmanagement.exception.BankManagementException;
import com.bankmanagement.vo.TransactionDetailsVO;
import com.bankmanagement.vo.UserVO;

@Service("service")
public class PerformTransactionServiceImpl implements PerformTransactionService {

	@Autowired
	private PerformTransactionDAO dao;

	@Autowired
	private UserDAO userDao;

	private final static String DEPOSIT = "deposit";
	private final static String WITHDRAWL = "withdrawl";
	private final static String SAVINGS = "savings";
	private final static String BALANCE_ERROR_KEY = "balanceError";
	private final static String ACCOUNT_ERROR_KEY = "accountError";

	@Transactional
	@Override
	public Double updateTransactionDetails(TransactionDetailsVO tdvo) throws BankManagementException {
		UserVO userVO = userDao.getUserDetails(tdvo.getAccountNumber());
		if (userVO == null) {
			throw new BankManagementException(ACCOUNT_ERROR_KEY,
					MessageFormat.format("Invalid account No: {0}", tdvo.getAccountNumber()));
		}

		Double accountBalance = userVO.getAccountBalance() == null ? 0 : userVO.getAccountBalance();
		Double transaction_amount = tdvo.getTransactionAmount();
		if (DEPOSIT.equalsIgnoreCase(tdvo.getTransactionType())) {
			accountBalance += transaction_amount;
			userVO.setAccountBalance(accountBalance);
			userDao.updateUserDetails(userVO);

		}

		if (WITHDRAWL.equalsIgnoreCase(tdvo.getTransactionType())) {

			String accountType = userVO.getAccountType();
			if (tdvo.getTransactionAmount() > userVO.getAccountBalance()) {
				throw new BankManagementException(BALANCE_ERROR_KEY,
						MessageFormat.format("Insufficient balance {0}", userVO.getAccountBalance()));

			}

			if (SAVINGS.equalsIgnoreCase(accountType)) {
				if ((userVO.getAccountBalance() - transaction_amount) < 5000) {
					throw new BankManagementException(BALANCE_ERROR_KEY,
							MessageFormat.format("Savings amount balance can't be less than {0}", 5000));

				}
			}

			accountBalance -= transaction_amount;
			userVO.setAccountBalance(accountBalance);

			userDao.updateUserDetails(userVO);
		}

		dao.updateTransactionDetails(tdvo);
		return accountBalance;

	}

}
