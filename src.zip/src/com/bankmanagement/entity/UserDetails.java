package com.bankmanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "TRANSACTION_DETAILS", schema = "bms")
public class UserDetails {

	@Column(name = "ACCOUNT_NUMBER")
	private Long accountNumber;

	@Id
	@Column(name = "TRANSACTION_ID")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long transactionId;

	@Column(name = "CUSTOMER_NAME")
	private String customerName;

	@Column(name = "TRANSACTION_TYPE")
	private String transactionType;

	@Column(name = "TRANSACTION_AMOUNT")
	private Double transactionAmount;

	@Column(name = "DESCRIPTION")
	private String description;

	public UserDetails() {
		// TODO Auto-generated constructor stub
	}

	public UserDetails(Long accountNumber, String customerName, String transactionType, Double transactionAmount,
			String description) {
		super();
		this.accountNumber = accountNumber;

		this.customerName = customerName;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.description = description;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public Long getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(Double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
