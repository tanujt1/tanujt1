package com.bankmanagement.exception;

public class BankManagementException extends Exception {
	private static final long serialVersionUID = 1L;

	private String errorKey;

	public BankManagementException(String errorKey, String message) {
		super(message);
		this.errorKey = errorKey;
	}

	public BankManagementException(Throwable throwale) {
		super(throwale);
	}

	public BankManagementException(String errorKey, String message, Throwable throwable) {
		super(message, throwable);
		this.errorKey = errorKey;
	}

	public String getErrorKey() {
		return errorKey;
	}

	public void setErrorKey(String errorKey) {
		this.errorKey = errorKey;
	}

}
